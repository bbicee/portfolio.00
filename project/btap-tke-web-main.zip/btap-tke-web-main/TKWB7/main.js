function myclick(){
   
    document.getElementById('list__child-active').classList.toggle('active-list__child')
}
function myclick1(){
   
    document.getElementById('list__child-active-1').classList.toggle('active-list__child')
}