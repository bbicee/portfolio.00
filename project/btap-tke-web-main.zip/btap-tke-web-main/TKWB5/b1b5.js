function ham(){
    document.write("Hello world");
    alert("Hello world");
}
